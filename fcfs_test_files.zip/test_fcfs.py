from math import isclose
from fcfs_simulator import Process, simulate_fcfs


test_cases = [
    (
        "TC01",
        [
            Process("P1", 0, 5),
            Process("P2", 1, 3),
            Process("P3", 2, 2),
            Process("P4", 4, 4),
        ],
        ["P1", "P2", "P3", "P4"],
        {
            "P1": (0, 5, 5, 0, 0),
            "P2": (5, 8, 7, 4, 4),
            "P3": (8, 10, 8, 6, 6),
            "P4": (10, 14, 10, 6, 6),
        },
        (4.00, 7.50, 4.00),
        [
            ("P1", 0, 5),
            ("P2", 5, 8),
            ("P3", 8, 10),
            ("P4", 10, 14),
        ],
    ),
    (
        "TC02",
        [
            Process("P1", 2, 3),
            Process("P2", 8, 2),
        ],
        ["P1", "P2"],
        {
            "P1": (2, 5, 3, 0, 0),
            "P2": (8, 10, 2, 0, 0),
        },
        (0.00, 2.50, 0.00),
        [
            ("IDLE", 0, 2),
            ("P1", 2, 5),
            ("IDLE", 5, 8),
            ("P2", 8, 10),
        ],
    ),
    (
        "TC03",
        [
            Process("P3", 0, 2),
            Process("P1", 0, 3),
            Process("P2", 0, 1),
        ],
        ["P1", "P2", "P3"],
        {
            "P1": (0, 3, 3, 0, 0),
            "P2": (3, 4, 4, 3, 3),
            "P3": (4, 6, 6, 4, 4),
        },
        (7 / 3, 13 / 3, 7 / 3),
        [
            ("P1", 0, 3),
            ("P2", 3, 4),
            ("P3", 4, 6),
        ],
    ),
    (
        "TC04",
        [Process("P1", 5, 4)],
        ["P1"],
        {
            "P1": (5, 9, 4, 0, 0),
        },
        (0.00, 4.00, 0.00),
        [
            ("IDLE", 0, 5),
            ("P1", 5, 9),
        ],
    ),
    (
        "TC05",
        [],
        [],
        {},
        (0.00, 0.00, 0.00),
        [],
    ),
]


for name, inputs, order, metrics, averages, expected_gantt in test_cases:
    result, awt, atat, art, gantt = simulate_fcfs(inputs)

    assert [p.pid for p in result] == order

    for p in result:
        actual_metrics = (p.st, p.ct, p.tat, p.wt, p.rt)
        assert actual_metrics == metrics[p.pid]

    actual_averages = (awt, atat, art)
    for actual, expected in zip(actual_averages, averages):
        assert isclose(actual, expected, abs_tol=0.01)

    assert gantt == expected_gantt
    print(name + ": PASS")

print("All scheduling test cases completed.")
