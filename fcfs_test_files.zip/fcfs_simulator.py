class Process:
    """Class representing a process and its scheduling metrics."""

    def __init__(self, pid, arrival_time, burst_time):
        self.pid = pid
        self.at = arrival_time
        self.bt = burst_time
        self.st = 0
        self.ct = 0
        self.tat = 0
        self.wt = 0
        self.rt = 0


def simulate_fcfs(processes):
    """Simulates FCFS CPU scheduling algorithm."""
    if not processes:
        return [], 0, 0, 0, []

    # Sort processes by Arrival Time (AT) ascending.
    processes.sort(key=lambda p: (p.at, p.pid))

    current_time = 0
    total_wt = 0
    total_tat = 0
    total_rt = 0
    gantt_chart = []

    for p in processes:
        # Check for CPU idle state.
        if current_time < p.at:
            gantt_chart.append(("IDLE", current_time, p.at))
            current_time = p.at

        # Calculate process execution times.
        p.st = current_time
        p.ct = p.st + p.bt
        current_time = p.ct

        # Record timeline for Gantt Chart.
        gantt_chart.append((p.pid, p.st, p.ct))

        # Calculate scheduling metrics.
        p.tat = p.ct - p.at
        p.wt = p.tat - p.bt
        p.rt = p.st - p.at

        # Accumulate totals for average metrics.
        total_wt += p.wt
        total_tat += p.tat
        total_rt += p.rt

    n = len(processes)
    awt = total_wt / n
    atat = total_tat / n
    art = total_rt / n

    return processes, awt, atat, art, gantt_chart


def print_gantt_chart(gantt_chart):
    """Displays terminal-based Gantt Chart."""
    print("\n--- GANTT CHART ---")

    # Top border.
    top_bar = "+"
    for block in gantt_chart:
        top_bar += "-------+"
    print(top_bar)

    # Process label row.
    label_bar = "|"
    for block in gantt_chart:
        label = block[0]
        label_bar += f" {label:^5} |"
    print(label_bar)

    # Bottom border.
    print(top_bar)

    # Time markers row.
    time_bar = f"{gantt_chart[0][1]:<7}"
    for block in gantt_chart:
        time_bar += f"{block[2]:<8}"
    print(time_bar)


def display_results(processes, awt, atat, art, gantt_chart):
    """Prints tabular results and aggregate metrics."""
    print("\n=========================================================================")
    print(f"{'PID':<8}{'AT':<8}{'BT':<8}{'ST':<8}{'CT':<8}{'TAT':<8}{'WT':<8}{'RT':<8}")
    print("=========================================================================")

    for p in processes:
        print(
            f"{p.pid:<8}{p.at:<8}{p.bt:<8}{p.st:<8}"
            f"{p.ct:<8}{p.tat:<8}{p.wt:<8}{p.rt:<8}"
        )

    print("=========================================================================")
    print(f"Average Waiting Time (AWT)    : {awt:.2f}")
    print(f"Average Turnaround Time (ATAT): {atat:.2f}")
    print(f"Average Response Time (ART)   : {art:.2f}")
    print_gantt_chart(gantt_chart)


if __name__ == "__main__":
    test_processes = [
        Process("P1", 0, 5),
        Process("P2", 1, 3),
        Process("P3", 2, 2),
        Process("P4", 4, 4),
    ]

    processed_list, awt, atat, art, gantt = simulate_fcfs(test_processes)
    display_results(processed_list, awt, atat, art, gantt)
